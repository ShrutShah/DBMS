
package employee.payroll.system;


public class Emp {
    public static int empId;
   
   
    
}
