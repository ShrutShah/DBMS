
package employee.payroll.system;



import java.sql.*;
import javax.swing.*;
public class db {
    
    
    
    Connection conn=null;
    public static Connection java_db(){
        
        try{
            //Class.forName("org.sqlite.JDBC");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost/testdb","test","password");
            //Connection conn =DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Hyrex\\Documents\\NetBeansProjects\\Employee Payroll System\\empnet.sqlite");
            JOptionPane.showMessageDialog(null, "Connection to database is successful");
      
            return con;
           
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
        
    }
}
